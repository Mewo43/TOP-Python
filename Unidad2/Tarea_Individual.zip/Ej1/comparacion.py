num1=int(input("Ingresa un numero: "))
num2=int(input("Ingresa un numero: "))
if(num1>num2):
    print("El ",num1," es mayor que el ",num2)
elif(num2>num1):
    print("El ",num2," es mayor que el ",num1)
else:
    print("Los dos numeros son iguales")